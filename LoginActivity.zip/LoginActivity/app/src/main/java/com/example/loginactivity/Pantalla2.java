package com.example.loginactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Pantalla2 extends AppCompatActivity {

    private EditText et_valor1, et_valor2, et_valor3;
    private RadioButton rb_div, rb_val;
    private TextView tv_resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla2);


        et_valor1 = (EditText) findViewById(R.id.txt_valor1);
        et_valor2 = (EditText) findViewById(R.id.txt_valor2);
        et_valor3 = (EditText) findViewById(R.id.txt_valor3);
        rb_div = (RadioButton) findViewById(R.id.rb_division);
        rb_val = (RadioButton) findViewById(R.id.rb_valor);
        tv_resultado = (TextView) findViewById(R.id.tv_resultado);

    }
    public void Anterior (View view){
        Intent anterior = new Intent(this, MainActivity.class);
        startActivity(anterior);
    }
    //Metodo para le botón
    public void Calcular(View view) {
        String valor1_String = et_valor1.getText().toString();
        String valor2_String = et_valor2.getText().toString();
        String valor3_String = et_valor3.getText().toString();

        int valor1_int = Integer.parseInt(valor1_String);
        int valor2_int = Integer.parseInt(valor2_String);
        int valor3_int = Integer.parseInt(valor3_String);

        if (rb_val.isChecked() == true) {
            int valor = valor1_int / valor2_int * valor3_int;
            String resultado = String.valueOf(valor);
            tv_resultado.setText(resultado);
        } else if (rb_div.isChecked() == true) {

            if (valor2_int != 0) {
                int division = valor1_int / valor2_int;
                String resultado = String.valueOf(division);
                tv_resultado.setText(resultado);
            } else {
                Toast.makeText(this, "El segundo valor debe ser diferente de cero", Toast.LENGTH_LONG).show();
            }


            }
        }
    }
